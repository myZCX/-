import java.util.*;
 
public class pailie{
	static int n;
	static int[] a;//一种排列情况
	static boolean[] b;//判断数字i是否已被使用
	
	static void dfs(int step){//step表示当前到了第几位
		if(step==n+1){//前n位已经放好，输出这种排列情况
			for(int i=1;i<=n;i++)
				System.out.print(a[i]);
			System.out.println();
            return;
		}
		for(int i=1;i<=n;i++){	
			if(!b[i]){//若数字i还未被使用
				a[step]=i;//在当前位上放i
				b[i]=true;//防止重用
				dfs(step+1);//放下一位数字
				b[i]=false;//回溯法，进行另一种尝试
			}
		}
		
	}
	public static void main(String[] args){
		Scanner in=new Scanner(System.in);
		n=in.nextInt();
		a=new int[n+1];
		b=new boolean[n+1];
		dfs(1);//从第一位开始放
	}
}